# textblob_sentiment_analysis
A streamlit python web app to analyze sentiment in a CSV file and add the sentiment values to the file. 
## Find the web app here:
https://sentimentalizer.streamlit.app/

